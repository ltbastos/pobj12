<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* components/modals/omega-modal.twig */
class __TwigTemplate_39e0bf39adfeff9a741a0eed2cfb72bab3605c25fd76235a82e4f920f9ff3ef8 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "  <div id=\"omega-modal\" class=\"omega-modal\" hidden>
    <div class=\"omega-modal__overlay\" data-omega-close></div>
    <section class=\"omega-modal__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-title\">
      <div id=\"omega-toast-stack\" class=\"omega-toast-stack\" aria-live=\"polite\" aria-atomic=\"true\"></div>
      <header class=\"omega-header\">
        <div class=\"omega-header__left\">
          <div class=\"omega-header__titles\">
            <h2 id=\"omega-title\">Central de chamados Omega</h2>
            <p id=\"omega-subtitle\">Registre ocorrências e acompanhe atendimentos.</p>
          </div>
        </div>
        <div class=\"omega-header__actions\">
          <!-- Toggle de tela cheia -->
          <button id=\"omega-fullscreen\" class=\"omega-icon-btn\" type=\"button\"
                  data-omega-fullscreen-toggle aria-pressed=\"false\"
                  aria-label=\"Entrar em tela cheia\" title=\"Tela cheia (F %}\">
            <i class=\"ti ti-arrows-maximize\"></i>
          </button>

          <button class=\"omega-icon-btn omega-header__close\" type=\"button\" data-omega-close aria-label=\"Fechar central Omega\">
            <i class=\"ti ti-x\"></i>
          </button>
          <div class=\"omega-notification-center\">
            <button id=\"omega-notifications\" class=\"omega-icon-btn\" type=\"button\" title=\"Notificações\" aria-expanded=\"false\" aria-controls=\"omega-notification-panel\">
              <i class=\"ti ti-bell\"></i>
              <span id=\"omega-notification-badge\" class=\"omega-notification-badge\" hidden>0</span>
            </button>
            <section id=\"omega-notification-panel\" class=\"omega-notification-panel\" role=\"dialog\" aria-modal=\"false\" aria-label=\"Notificações\" hidden>
              <header class=\"omega-notification-panel__header\">
                <strong>Notificações</strong>
                <button id=\"omega-notification-close\" class=\"omega-icon-btn\" type=\"button\" aria-label=\"Fechar notificações\">
                  <i class=\"ti ti-x\"></i>
                </button>
              </header>
              <div class=\"omega-notification-panel__body\">
                <ul id=\"omega-notification-list\" class=\"omega-notification-list\"></ul>
                <p id=\"omega-notification-empty\" class=\"omega-notification-empty\">Nenhuma notificação registrada.</p>
              </div>
            </section>
          </div>
          <label class=\"omega-user-switch\" for=\"omega-user-select\">
            <span class=\"sr-only\">Trocar perfil</span>
            <select id=\"omega-user-select\" class=\"omega-select\" aria-label=\"Trocar perfil\"></select>
          </label>
        </div>
      </header>

      <div class=\"omega-body\">
        <aside class=\"omega-sidebar\" id=\"omega-sidebar\">
          <button id=\"omega-sidebar-toggle\" class=\"omega-sidebar__toggle\" type=\"button\" aria-label=\"Recolher menu\" aria-pressed=\"false\" aria-expanded=\"true\" title=\"Recolher menu\">
            <span class=\"sr-only\">Alternar menu</span>
            <i class=\"ti ti-chevron-left\" aria-hidden=\"true\"></i>
          </button>
          <section class=\"omega-profile\" aria-label=\"Perfil selecionado\">
            <figure class=\"omega-avatar\" aria-hidden=\"true\">
              <img id=\"omega-avatar\" alt=\"\" loading=\"lazy\" hidden/>
            </figure>
            <strong id=\"omega-user-name\" class=\"omega-profile__name\">—</strong>
          </section>

          <nav id=\"omega-nav\" class=\"omega-nav\" aria-label=\"Menu Omega\"></nav>

        </aside>

        <section class=\"omega-main\">
          <div id=\"omega-breadcrumb\" class=\"omega-breadcrumb\"></div>
          <div id=\"omega-context\" class=\"omega-context\" hidden></div>

          <div class=\"omega-toolbar\" role=\"group\" aria-label=\"Filtros da central Omega\">
            <label class=\"omega-search\" for=\"omega-search\">
              <i class=\"ti ti-search\"></i>
              <input id=\"omega-search\" type=\"search\" placeholder=\"Buscar chamado ou usuário\" autocomplete=\"off\"/>
            </label>
            <div class=\"omega-toolbar__actions\">
              <div class=\"omega-toolbar__cluster\">
                <div class=\"omega-filters\">
                  <button id=\"omega-filters-toggle\" class=\"omega-btn omega-btn--ghost\" type=\"button\" aria-haspopup=\"dialog\" aria-expanded=\"false\" aria-controls=\"omega-filter-panel\">
                    <i class=\"ti ti-adjustments-horizontal\"></i>
                    <span>Filtros</span>
                  </button>
                  <button id=\"omega-clear-filters-top\" class=\"omega-btn omega-btn--ghost\" type=\"button\">
                    <i class=\"ti ti-x\"></i>
                    <span>Limpar filtros</span>
                  </button>
                  <button id=\"omega-refresh\" class=\"omega-btn omega-btn--ghost\" type=\"button\">
                    <i class=\"ti ti-refresh\"></i>
                    <span>Atualizar lista</span>
                  </button>
                  <div id=\"omega-filter-panel\" class=\"omega-filter-panel\" role=\"dialog\" aria-modal=\"false\" hidden>
                    <form id=\"omega-filter-form\" class=\"omega-filter-form\">
                      <div class=\"omega-filter-form__grid\">
                        <label class=\"omega-field\" for=\"omega-filter-id\">
                          <span class=\"omega-field__label\">ID do chamado</span>
                          <input id=\"omega-filter-id\" class=\"omega-input\" type=\"text\" placeholder=\"Ex.: OME-2025-0001\" autocomplete=\"off\"/>
                        </label>
                        <label class=\"omega-field\" for=\"omega-filter-user\">
                          <span class=\"omega-field__label\">Usuário</span>
                          <input id=\"omega-filter-user\" class=\"omega-input\" type=\"text\" placeholder=\"Digite um nome\" autocomplete=\"off\"/>
                        </label>
                        <label class=\"omega-field\" for=\"omega-filter-department\">
                          <span class=\"omega-field__label\">Departamento</span>
                          <select id=\"omega-filter-department\" class=\"omega-select\" aria-describedby=\"omega-filter-department-hint\"></select>
                          <small id=\"omega-filter-department-hint\" class=\"omega-hint\">Escolha a fila desejada</small>
                        </label>
                        <label class=\"omega-field\" for=\"omega-filter-type\">
                          <span class=\"omega-field__label\">Tipo de chamado</span>
                          <select id=\"omega-filter-type\" class=\"omega-select\"></select>
                        </label>
                        <label class=\"omega-field\" for=\"omega-filter-priority\">
                          <span class=\"omega-field__label\">Prioridade</span>
                          <select id=\"omega-filter-priority\" class=\"omega-select\">
                            <option value=\"\">Todas</option>
                          </select>
                        </label>
                        <fieldset class=\"omega-field omega-filter-form__status\" aria-describedby=\"omega-filter-status-hint\">
                          <span class=\"omega-field__label\">Status do chamado</span>
                          <div id=\"omega-filter-status\" class=\"omega-filter-status\"></div>
                          <small id=\"omega-filter-status-hint\" class=\"omega-hint\">Selecione um ou mais status</small>
                        </fieldset>
                        <div class=\"omega-filter-form__dates\">
                          <label class=\"omega-field\" for=\"omega-filter-from\">
                            <span class=\"omega-field__label\">Abertura desde</span>
                            <input id=\"omega-filter-from\" class=\"omega-input\" type=\"date\"/>
                          </label>
                          <label class=\"omega-field\" for=\"omega-filter-to\">
                            <span class=\"omega-field__label\">Até</span>
                            <input id=\"omega-filter-to\" class=\"omega-input\" type=\"date\"/>
                          </label>
                        </div>
                      </div>
                      <footer class=\"omega-filter-form__actions\">
                        <button id=\"omega-clear-filters\" class=\"omega-btn omega-btn--ghost\" type=\"button\">Limpar filtros</button>
                        <button class=\"omega-btn omega-btn--primary\" type=\"submit\">
                          <i class=\"ti ti-check\"></i>
                          <span>Aplicar</span>
                        </button>
                      </footer>
                    </form>
                  </div>
                </div>
              </div>
              <button id=\"omega-bulk-status\" class=\"omega-btn omega-btn--ghost\" type=\"button\" hidden>
                <i class=\"ti ti-arrows-exchange\"></i>
                <span>Alterar status</span>
              </button>
              <button id=\"omega-new-ticket\" class=\"omega-btn omega-btn--primary\" type=\"button\">
                <i class=\"ti ti-plus\"></i>
                <span>Registrar chamado</span>
              </button>
            </div>
          </div>

          <div id=\"omega-bulk-panel\" class=\"omega-bulk-panel\" role=\"dialog\" aria-modal=\"false\" hidden>
            <form id=\"omega-bulk-form\" class=\"omega-bulk-form\">
              <header class=\"omega-bulk-form__header\">
                <strong>Alterar status</strong>
                <button type=\"button\" class=\"omega-icon-btn\" id=\"omega-bulk-close\" aria-label=\"Fechar\">
                  <i class=\"ti ti-x\"></i>
                </button>
              </header>
              <p id=\"omega-bulk-hint\">Selecione os chamados desejados para aplicar o novo status.</p>
              <label class=\"omega-field\" for=\"omega-bulk-status-select\">
                <span class=\"omega-field__label\">Novo status</span>
                <select id=\"omega-bulk-status-select\" class=\"omega-select\" required></select>
              </label>
              <footer class=\"omega-bulk-form__actions\">
                <button type=\"button\" class=\"omega-btn omega-btn--ghost\" id=\"omega-bulk-cancel\">Cancelar</button>
                <button type=\"submit\" class=\"omega-btn omega-btn--primary\">
                  <i class=\"ti ti-check\"></i>
                  <span>Aplicar</span>
                </button>
              </footer>
            </form>
          </div>

          <div id=\"omega-summary\" class=\"omega-summary\" aria-live=\"polite\"></div>

          <div class=\"omega-main__content\">
            <div id=\"omega-dashboard\" class=\"omega-dashboard\" hidden aria-live=\"polite\"></div>
            <div id=\"omega-table-wrapper\" class=\"omega-table-wrapper\" role=\"region\" aria-labelledby=\"omega-table-caption\">
              <table class=\"omega-table\" id=\"omega-ticket-table\">
                <caption id=\"omega-table-caption\" class=\"sr-only\">Chamados filtrados pela visão atual</caption>
                <thead>
                  <tr>
                    <th scope=\"col\" class=\"col-select\" aria-label=\"Selecionar\">
                      <input id=\"omega-select-all\" type=\"checkbox\" aria-label=\"Selecionar todos\"/>
                    </th>
                    <th scope=\"col\">ID</th>
                    <th scope=\"col\">Prévia</th>
                    <th scope=\"col\">Departamento</th>
                    <th scope=\"col\">Tipo</th>
                    <th scope=\"col\">Usuário</th>
                    <th scope=\"col\" data-priority-column>Prioridade</th>
                    <th scope=\"col\">Produto</th>
                    <th scope=\"col\">Fila</th>
                    <th scope=\"col\">Abertura</th>
                    <th scope=\"col\">Atualização</th>
                    <th scope=\"col\" class=\"col-status\">Status</th>
                  </tr>
                </thead>
                <tbody id=\"omega-ticket-rows\"></tbody>
              </table>
            </div>
            <footer class=\"omega-table-footer\" aria-live=\"polite\" hidden>
              <span id=\"omega-table-range\" class=\"omega-table-range\">—</span>
              <nav id=\"omega-pagination\" class=\"omega-pagination\" aria-label=\"Paginação de chamados\"></nav>
            </footer>
          </div>
        </section>

      </div>

      <div id=\"omega-drawer\" class=\"omega-drawer\" hidden>
        <div class=\"omega-drawer__overlay\" data-omega-drawer-close></div>
        <section class=\"omega-drawer__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-drawer-title\">
          <header class=\"omega-drawer__header\">
            <div>
              <h3 id=\"omega-drawer-title\">Novo chamado</h3>
              <p id=\"omega-drawer-desc\">Preencha os campos abaixo para registrar o chamado com agilidade.</p>
            </div>
            <button class=\"omega-icon-btn\" type=\"button\" data-omega-drawer-close aria-label=\"Fechar formulário\">
              <i class=\"ti ti-x\"></i>
            </button>
          </header>
          <div id=\"omega-form-feedback\" class=\"omega-feedback\" role=\"alert\" hidden></div>
          <form id=\"omega-form\" class=\"omega-form\">
            <div class=\"omega-field omega-field--static\" aria-live=\"polite\">
              <span class=\"omega-field__label\">Solicitante</span>
              <div id=\"omega-form-requester\" class=\"omega-field__static\">—</div>
            </div>

            <div class=\"omega-form__grid\">
              <label class=\"omega-field\" for=\"omega-form-department\">
                <span class=\"omega-field__label\">Departamento</span>
                <select id=\"omega-form-department\" class=\"omega-select\" required></select>
              </label>
              <label class=\"omega-field\" for=\"omega-form-type\">
                <span class=\"omega-field__label\">Tipo de chamado</span>
                <select id=\"omega-form-type\" class=\"omega-select\" required></select>
              </label>
            </div>

            <label class=\"omega-field\" for=\"omega-form-observation\">
              <span class=\"omega-field__label\">Observação</span>
              <textarea id=\"omega-form-observation\" class=\"omega-textarea\" rows=\"6\" placeholder=\"Descreva a demanda\" required></textarea>
            </label>

            <section id=\"omega-form-flow\" class=\"omega-form-flow\" hidden aria-hidden=\"true\" data-omega-flow>
              <header class=\"omega-form-flow__header\">
                <h4>Fluxo de aprovações</h4>
                <p>Esta transferência exige os de acordo dos gerentes listados abaixo.</p>
              </header>
              <div class=\"omega-form-flow__approvals\">
                <article class=\"omega-flow-approval\">
                  <div class=\"omega-flow-approval__icon\" aria-hidden=\"true\"><i class=\"ti ti-user-check\"></i></div>
                  <div class=\"omega-flow-approval__body\">
                    <span class=\"omega-flow-approval__label\">Gerente da agência solicitante</span>
                    <label class=\"omega-field\" for=\"omega-flow-requester-name\">
                      <span class=\"omega-field__label\">Nome completo</span>
                      <input id=\"omega-flow-requester-name\" class=\"omega-input\" type=\"text\" placeholder=\"Informe o gerente responsável\"/>
                    </label>
                    <label class=\"omega-field\" for=\"omega-flow-requester-email\">
                      <span class=\"omega-field__label\">E-mail corporativo</span>
                      <input id=\"omega-flow-requester-email\" class=\"omega-input\" type=\"email\" placeholder=\"nome.sobrenome@empresa.com\"/>
                    </label>
                  </div>
                </article>
                <article class=\"omega-flow-approval\">
                  <div class=\"omega-flow-approval__icon\" aria-hidden=\"true\"><i class=\"ti ti-building-bank\"></i></div>
                  <div class=\"omega-flow-approval__body\">
                    <span class=\"omega-flow-approval__label\">Gerente da agência cedente</span>
                    <label class=\"omega-field\" for=\"omega-flow-target-name\">
                      <span class=\"omega-field__label\">Nome completo</span>
                      <input id=\"omega-flow-target-name\" class=\"omega-input\" type=\"text\" placeholder=\"Informe o gerente responsável\"/>
                    </label>
                    <label class=\"omega-field\" for=\"omega-flow-target-email\">
                      <span class=\"omega-field__label\">E-mail corporativo</span>
                      <input id=\"omega-flow-target-email\" class=\"omega-input\" type=\"email\" placeholder=\"nome.sobrenome@empresa.com\"/>
                    </label>
                  </div>
                </article>
              </div>
              <p class=\"omega-form-flow__hint\">Após os dois de acordo, o chamado entra automaticamente na fila de Encarteiramento.</p>
            </section>

            <div class=\"omega-field omega-field--attachments\">
              <span class=\"omega-field__label\" id=\"omega-form-file-label\">Arquivos</span>
              <input id=\"omega-form-file\" class=\"sr-only\" type=\"file\" multiple aria-labelledby=\"omega-form-file-label\"/>
              <div class=\"omega-attachments\">
                <div class=\"omega-attachments__actions\">
                  <button class=\"omega-btn\" type=\"button\" data-omega-add-file>
                    <i class=\"ti ti-paperclip\"></i>
                    <span>Adicionar arquivo</span>
                  </button>
                </div>
                <ul id=\"omega-form-attachments\" class=\"omega-attachments__list\" aria-live=\"polite\"></ul>
              </div>
            </div>

            <input id=\"omega-form-product\" type=\"hidden\"/>
            <input id=\"omega-form-subject\" type=\"hidden\"/>

            <footer class=\"omega-form__actions\">
              <button class=\"omega-btn\" type=\"button\" data-omega-drawer-close>Cancelar</button>
              <button class=\"omega-btn omega-btn--primary\" type=\"submit\">
                <i class=\"ti ti-device-floppy\"></i>
                <span>Salvar</span>
              </button>
            </footer>
          </form>
        </section>
      </div>

      <div id=\"omega-ticket-modal\" class=\"omega-ticket-modal\" hidden>
        <div class=\"omega-ticket-modal__overlay\" data-omega-ticket-close></div>
        <section class=\"omega-ticket-modal__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-ticket-modal-title\">
          <header class=\"omega-ticket-modal__header\">
            <div class=\"omega-ticket-modal__titles\">
              <h3 id=\"omega-ticket-modal-title\">Detalhe do chamado</h3>
              <p id=\"omega-ticket-modal-meta\">—</p>
            </div>
            <button class=\"omega-icon-btn\" type=\"button\" data-omega-ticket-close title=\"Fechar detalhamento\">
              <i class=\"ti ti-x\"></i>
            </button>
          </header>
          <div class=\"omega-ticket-modal__body\">
            <section class=\"omega-ticket-progress\" aria-live=\"polite\">
              <ol id=\"omega-ticket-progress\" class=\"omega-progress\"></ol>
            </section>
            <section class=\"omega-ticket-overview\" aria-labelledby=\"omega-ticket-overview-title\">
              <h4 id=\"omega-ticket-overview-title\">Informações do chamado</h4>
              <div class=\"omega-ticket-overview__grid\">
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Solicitante</span>
                  <strong id=\"omega-ticket-requester\">—</strong>
                  <small id=\"omega-ticket-requester-meta\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Responsável</span>
                  <strong id=\"omega-ticket-owner\">—</strong>
                  <small id=\"omega-ticket-owner-meta\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Produto</span>
                  <strong id=\"omega-ticket-product\">—</strong>
                  <small id=\"omega-ticket-queue\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Abertura</span>
                  <strong id=\"omega-ticket-opened\">—</strong>
                  <small id=\"omega-ticket-opened-time\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Status</span>
                  <strong id=\"omega-ticket-status\">—</strong>
                  <small id=\"omega-ticket-updated\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Prioridade</span>
                  <strong id=\"omega-ticket-priority\">—</strong>
                  <small id=\"omega-ticket-due\">—</small>
                </article>
              </div>
            </section>
            <section class=\"omega-ticket-description\" aria-labelledby=\"omega-ticket-description-title\">
              <div class=\"omega-ticket-description__header\">
                <h4 id=\"omega-ticket-description-title\">Descrição</h4>
                <span id=\"omega-ticket-id\">—</span>
              </div>
              <div id=\"omega-ticket-description\" class=\"omega-ticket-description__content\">—</div>
            </section>
            <section class=\"omega-ticket-timeline\" aria-labelledby=\"omega-ticket-timeline-title\">
              <h4 id=\"omega-ticket-timeline-title\">Linha do tempo</h4>
              <ol id=\"omega-ticket-timeline\" class=\"omega-timeline\"></ol>
            </section>
            <section id=\"omega-ticket-actions\" class=\"omega-ticket-actions\" aria-labelledby=\"omega-ticket-actions-title\" hidden>
              <h4 id=\"omega-ticket-actions-title\">Registrar atualização</h4>
              <form id=\"omega-ticket-update-form\" class=\"omega-ticket-actions__form\">
                <div id=\"omega-ticket-actions-advanced\" class=\"omega-ticket-actions__advanced\" hidden>
                  <label class=\"omega-field\" for=\"omega-ticket-update-status\">
                    <span class=\"omega-field__label\">Status</span>
                    <select id=\"omega-ticket-update-status\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-priority\">
                    <span class=\"omega-field__label\">Prioridade</span>
                    <select id=\"omega-ticket-update-priority\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-queue\">
                    <span class=\"omega-field__label\">Fila</span>
                    <select id=\"omega-ticket-update-queue\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-owner\">
                    <span class=\"omega-field__label\">Analista responsável</span>
                    <select id=\"omega-ticket-update-owner\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-category\">
                    <span class=\"omega-field__label\">Tipo de chamado</span>
                    <select id=\"omega-ticket-update-category\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-due\">
                    <span class=\"omega-field__label\">Prazo</span>
                    <input id=\"omega-ticket-update-due\" class=\"omega-input\" type=\"date\"/>
                  </label>
                </div>
                <label class=\"omega-field\" for=\"omega-ticket-update-comment\">
                  <span class=\"omega-field__label\">Comentário</span>
                  <textarea id=\"omega-ticket-update-comment\" class=\"omega-textarea\" rows=\"4\" placeholder=\"Descreva o andamento\" required></textarea>
                </label>
                <div class=\"omega-field omega-field--attachments\">
                  <span class=\"omega-field__label\" id=\"omega-ticket-update-file-label\">Anexos</span>
                  <input id=\"omega-ticket-update-file\" class=\"sr-only\" type=\"file\" multiple aria-labelledby=\"omega-ticket-update-file-label\"/>
                  <div class=\"omega-attachments\">
                    <div class=\"omega-attachments__actions\">
                      <button class=\"omega-btn\" type=\"button\" data-omega-ticket-add-file>
                        <i class=\"ti ti-paperclip\"></i>
                        <span>Adicionar arquivo</span>
                      </button>
                    </div>
                    <ul id=\"omega-ticket-update-attachments\" class=\"omega-attachments__list\" aria-live=\"polite\"></ul>
                  </div>
                </div>
                <footer class=\"omega-ticket-actions__footer\">
                  <button id=\"omega-ticket-cancel\" class=\"omega-btn omega-btn--danger\" type=\"button\" hidden>
                    <i class=\"ti ti-circle-x\"></i>
                    <span>Cancelar chamado</span>
                  </button>
                  <div class=\"omega-ticket-actions__controls\">
                    <button id=\"omega-ticket-update-reset\" class=\"omega-btn omega-btn--ghost\" type=\"button\">Limpar</button>
                    <button class=\"omega-btn omega-btn--primary\" type=\"submit\">
                      <i class=\"ti ti-message-plus\"></i>
                      <span>Registrar atualização</span>
                    </button>
                  </div>
                </footer>
              </form>
            </section>
          </div>
        </section>
      </div>

      <div id=\"omega-cancel-dialog\" class=\"omega-confirm\" hidden>
        <div class=\"omega-confirm__overlay\" data-omega-cancel-close></div>
        <section class=\"omega-confirm__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-cancel-title\">
          <header class=\"omega-confirm__header\">
            <i class=\"ti ti-circle-x\" aria-hidden=\"true\"></i>
            <div>
              <h3 id=\"omega-cancel-title\">Cancelar chamado</h3>
              <p>Revise as informações antes de confirmar o cancelamento.</p>
            </div>
          </header>
          <div class=\"omega-confirm__body\">
            <div class=\"omega-confirm__ticket\">
              <span>Chamado</span>
              <strong id=\"omega-cancel-ticket-id\">—</strong>
              <small id=\"omega-cancel-ticket-subject\">—</small>
            </div>
            <dl class=\"omega-confirm__meta\">
              <div>
                <dt>Status atual</dt>
                <dd id=\"omega-cancel-ticket-status\">—</dd>
              </div>
              <div>
                <dt>Solicitante</dt>
                <dd id=\"omega-cancel-ticket-requester\">—</dd>
              </div>
            </dl>
            <p id=\"omega-cancel-message\" class=\"omega-confirm__message\">Tem certeza de que deseja cancelar este chamado?</p>
          </div>
          <footer class=\"omega-confirm__actions\">
            <button type=\"button\" class=\"omega-btn omega-btn--ghost\" data-omega-cancel-dismiss>Manter chamado</button>
            <button type=\"button\" class=\"omega-btn omega-btn--danger\" data-omega-cancel-confirm>
              <i class=\"ti ti-circle-x\"></i>
              <span>Cancelar chamado</span>
            </button>
          </footer>
        </section>
      </div>

      <div id=\"omega-manage-analyst\" class=\"omega-manage-modal\" hidden>
        <div class=\"omega-manage-modal__overlay\" data-omega-manage-analyst-close></div>
        <section class=\"omega-manage-modal__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-manage-analyst-title\">
          <header class=\"omega-manage-modal__header\">
            <div>
              <h3 id=\"omega-manage-analyst-title\">Editar analistas</h3>
              <p>Atualize as filas atendidas pelos analistas da sua equipe.</p>
            </div>
            <button type=\"button\" class=\"omega-icon-btn\" data-omega-manage-analyst-close aria-label=\"Fechar edição de analistas\">
              <i class=\"ti ti-x\"></i>
            </button>
          </header>
          <form id=\"omega-manage-analyst-form\" class=\"omega-manage-modal__form\">
            <label class=\"omega-field\" for=\"omega-manage-analyst-select\">
              <span class=\"omega-field__label\">Analista</span>
              <select id=\"omega-manage-analyst-select\" class=\"omega-select\"></select>
            </label>
            <fieldset class=\"omega-field\" aria-describedby=\"omega-manage-analyst-hint\">
              <legend class=\"omega-field__label\">Filas atendidas</legend>
              <div id=\"omega-manage-analyst-queues\" class=\"omega-manage-list\"></div>
              <small id=\"omega-manage-analyst-hint\" class=\"omega-hint\">Marque as filas que o analista deverá acompanhar.</small>
            </fieldset>
            <footer class=\"omega-manage-modal__actions\">
              <button type=\"button\" class=\"omega-btn\" data-omega-manage-analyst-close>Cancelar</button>
              <button type=\"submit\" class=\"omega-btn omega-btn--primary\">
                <i class=\"ti ti-device-floppy\"></i>
                <span>Salvar alterações</span>
              </button>
            </footer>
          </form>
          <div id=\"omega-manage-analyst-empty\" class=\"omega-manage-modal__empty\" hidden></div>
        </section>
      </div>

      <div id=\"omega-manage-status\" class=\"omega-manage-modal\" hidden>
        <div class=\"omega-manage-modal__overlay\" data-omega-manage-status-close></div>
        <section class=\"omega-manage-modal__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-manage-status-title\">
          <header class=\"omega-manage-modal__header\">
            <div>
              <h3 id=\"omega-manage-status-title\">Editar status</h3>
              <p>Personalize os status disponíveis para as filas selecionadas.</p>
            </div>
            <button type=\"button\" class=\"omega-icon-btn\" data-omega-manage-status-close aria-label=\"Fechar edição de status\">
              <i class=\"ti ti-x\"></i>
            </button>
          </header>
          <form id=\"omega-manage-status-form\" class=\"omega-manage-modal__form\">
            <label class=\"omega-field\" for=\"omega-manage-status-department\">
              <span class=\"omega-field__label\">Fila</span>
              <select id=\"omega-manage-status-department\" class=\"omega-select\"></select>
            </label>
            <label class=\"omega-field\" for=\"omega-manage-status-select\">
              <span class=\"omega-field__label\">Status</span>
              <select id=\"omega-manage-status-select\" class=\"omega-select\"></select>
            </label>
            <label class=\"omega-field\" for=\"omega-manage-status-label\">
              <span class=\"omega-field__label\">Título</span>
              <input id=\"omega-manage-status-label\" class=\"omega-input\" type=\"text\" placeholder=\"Nome do status\"/>
            </label>
            <label class=\"omega-field\" for=\"omega-manage-status-tone\">
              <span class=\"omega-field__label\">Tom</span>
              <select id=\"omega-manage-status-tone\" class=\"omega-select\"></select>
            </label>
            <label class=\"omega-field\" for=\"omega-manage-status-description\">
              <span class=\"omega-field__label\">Descrição</span>
              <textarea id=\"omega-manage-status-description\" class=\"omega-textarea\" rows=\"3\" placeholder=\"Quando esse status deve ser utilizado?\"></textarea>
            </label>
            <footer class=\"omega-manage-modal__actions\">
              <button type=\"button\" class=\"omega-btn\" data-omega-manage-status-close>Cancelar</button>
              <button type=\"submit\" class=\"omega-btn omega-btn--primary\">
                <i class=\"ti ti-device-floppy\"></i>
                <span>Salvar alterações</span>
              </button>
            </footer>
          </form>
          <div id=\"omega-manage-status-empty\" class=\"omega-manage-modal__empty\" hidden></div>
        </section>
      </div>
    </section>
  </div>

";
    }

    public function getTemplateName()
    {
        return "components/modals/omega-modal.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("  <div id=\"omega-modal\" class=\"omega-modal\" hidden>
    <div class=\"omega-modal__overlay\" data-omega-close></div>
    <section class=\"omega-modal__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-title\">
      <div id=\"omega-toast-stack\" class=\"omega-toast-stack\" aria-live=\"polite\" aria-atomic=\"true\"></div>
      <header class=\"omega-header\">
        <div class=\"omega-header__left\">
          <div class=\"omega-header__titles\">
            <h2 id=\"omega-title\">Central de chamados Omega</h2>
            <p id=\"omega-subtitle\">Registre ocorrências e acompanhe atendimentos.</p>
          </div>
        </div>
        <div class=\"omega-header__actions\">
          <!-- Toggle de tela cheia -->
          <button id=\"omega-fullscreen\" class=\"omega-icon-btn\" type=\"button\"
                  data-omega-fullscreen-toggle aria-pressed=\"false\"
                  aria-label=\"Entrar em tela cheia\" title=\"Tela cheia (F %}\">
            <i class=\"ti ti-arrows-maximize\"></i>
          </button>

          <button class=\"omega-icon-btn omega-header__close\" type=\"button\" data-omega-close aria-label=\"Fechar central Omega\">
            <i class=\"ti ti-x\"></i>
          </button>
          <div class=\"omega-notification-center\">
            <button id=\"omega-notifications\" class=\"omega-icon-btn\" type=\"button\" title=\"Notificações\" aria-expanded=\"false\" aria-controls=\"omega-notification-panel\">
              <i class=\"ti ti-bell\"></i>
              <span id=\"omega-notification-badge\" class=\"omega-notification-badge\" hidden>0</span>
            </button>
            <section id=\"omega-notification-panel\" class=\"omega-notification-panel\" role=\"dialog\" aria-modal=\"false\" aria-label=\"Notificações\" hidden>
              <header class=\"omega-notification-panel__header\">
                <strong>Notificações</strong>
                <button id=\"omega-notification-close\" class=\"omega-icon-btn\" type=\"button\" aria-label=\"Fechar notificações\">
                  <i class=\"ti ti-x\"></i>
                </button>
              </header>
              <div class=\"omega-notification-panel__body\">
                <ul id=\"omega-notification-list\" class=\"omega-notification-list\"></ul>
                <p id=\"omega-notification-empty\" class=\"omega-notification-empty\">Nenhuma notificação registrada.</p>
              </div>
            </section>
          </div>
          <label class=\"omega-user-switch\" for=\"omega-user-select\">
            <span class=\"sr-only\">Trocar perfil</span>
            <select id=\"omega-user-select\" class=\"omega-select\" aria-label=\"Trocar perfil\"></select>
          </label>
        </div>
      </header>

      <div class=\"omega-body\">
        <aside class=\"omega-sidebar\" id=\"omega-sidebar\">
          <button id=\"omega-sidebar-toggle\" class=\"omega-sidebar__toggle\" type=\"button\" aria-label=\"Recolher menu\" aria-pressed=\"false\" aria-expanded=\"true\" title=\"Recolher menu\">
            <span class=\"sr-only\">Alternar menu</span>
            <i class=\"ti ti-chevron-left\" aria-hidden=\"true\"></i>
          </button>
          <section class=\"omega-profile\" aria-label=\"Perfil selecionado\">
            <figure class=\"omega-avatar\" aria-hidden=\"true\">
              <img id=\"omega-avatar\" alt=\"\" loading=\"lazy\" hidden/>
            </figure>
            <strong id=\"omega-user-name\" class=\"omega-profile__name\">—</strong>
          </section>

          <nav id=\"omega-nav\" class=\"omega-nav\" aria-label=\"Menu Omega\"></nav>

        </aside>

        <section class=\"omega-main\">
          <div id=\"omega-breadcrumb\" class=\"omega-breadcrumb\"></div>
          <div id=\"omega-context\" class=\"omega-context\" hidden></div>

          <div class=\"omega-toolbar\" role=\"group\" aria-label=\"Filtros da central Omega\">
            <label class=\"omega-search\" for=\"omega-search\">
              <i class=\"ti ti-search\"></i>
              <input id=\"omega-search\" type=\"search\" placeholder=\"Buscar chamado ou usuário\" autocomplete=\"off\"/>
            </label>
            <div class=\"omega-toolbar__actions\">
              <div class=\"omega-toolbar__cluster\">
                <div class=\"omega-filters\">
                  <button id=\"omega-filters-toggle\" class=\"omega-btn omega-btn--ghost\" type=\"button\" aria-haspopup=\"dialog\" aria-expanded=\"false\" aria-controls=\"omega-filter-panel\">
                    <i class=\"ti ti-adjustments-horizontal\"></i>
                    <span>Filtros</span>
                  </button>
                  <button id=\"omega-clear-filters-top\" class=\"omega-btn omega-btn--ghost\" type=\"button\">
                    <i class=\"ti ti-x\"></i>
                    <span>Limpar filtros</span>
                  </button>
                  <button id=\"omega-refresh\" class=\"omega-btn omega-btn--ghost\" type=\"button\">
                    <i class=\"ti ti-refresh\"></i>
                    <span>Atualizar lista</span>
                  </button>
                  <div id=\"omega-filter-panel\" class=\"omega-filter-panel\" role=\"dialog\" aria-modal=\"false\" hidden>
                    <form id=\"omega-filter-form\" class=\"omega-filter-form\">
                      <div class=\"omega-filter-form__grid\">
                        <label class=\"omega-field\" for=\"omega-filter-id\">
                          <span class=\"omega-field__label\">ID do chamado</span>
                          <input id=\"omega-filter-id\" class=\"omega-input\" type=\"text\" placeholder=\"Ex.: OME-2025-0001\" autocomplete=\"off\"/>
                        </label>
                        <label class=\"omega-field\" for=\"omega-filter-user\">
                          <span class=\"omega-field__label\">Usuário</span>
                          <input id=\"omega-filter-user\" class=\"omega-input\" type=\"text\" placeholder=\"Digite um nome\" autocomplete=\"off\"/>
                        </label>
                        <label class=\"omega-field\" for=\"omega-filter-department\">
                          <span class=\"omega-field__label\">Departamento</span>
                          <select id=\"omega-filter-department\" class=\"omega-select\" aria-describedby=\"omega-filter-department-hint\"></select>
                          <small id=\"omega-filter-department-hint\" class=\"omega-hint\">Escolha a fila desejada</small>
                        </label>
                        <label class=\"omega-field\" for=\"omega-filter-type\">
                          <span class=\"omega-field__label\">Tipo de chamado</span>
                          <select id=\"omega-filter-type\" class=\"omega-select\"></select>
                        </label>
                        <label class=\"omega-field\" for=\"omega-filter-priority\">
                          <span class=\"omega-field__label\">Prioridade</span>
                          <select id=\"omega-filter-priority\" class=\"omega-select\">
                            <option value=\"\">Todas</option>
                          </select>
                        </label>
                        <fieldset class=\"omega-field omega-filter-form__status\" aria-describedby=\"omega-filter-status-hint\">
                          <span class=\"omega-field__label\">Status do chamado</span>
                          <div id=\"omega-filter-status\" class=\"omega-filter-status\"></div>
                          <small id=\"omega-filter-status-hint\" class=\"omega-hint\">Selecione um ou mais status</small>
                        </fieldset>
                        <div class=\"omega-filter-form__dates\">
                          <label class=\"omega-field\" for=\"omega-filter-from\">
                            <span class=\"omega-field__label\">Abertura desde</span>
                            <input id=\"omega-filter-from\" class=\"omega-input\" type=\"date\"/>
                          </label>
                          <label class=\"omega-field\" for=\"omega-filter-to\">
                            <span class=\"omega-field__label\">Até</span>
                            <input id=\"omega-filter-to\" class=\"omega-input\" type=\"date\"/>
                          </label>
                        </div>
                      </div>
                      <footer class=\"omega-filter-form__actions\">
                        <button id=\"omega-clear-filters\" class=\"omega-btn omega-btn--ghost\" type=\"button\">Limpar filtros</button>
                        <button class=\"omega-btn omega-btn--primary\" type=\"submit\">
                          <i class=\"ti ti-check\"></i>
                          <span>Aplicar</span>
                        </button>
                      </footer>
                    </form>
                  </div>
                </div>
              </div>
              <button id=\"omega-bulk-status\" class=\"omega-btn omega-btn--ghost\" type=\"button\" hidden>
                <i class=\"ti ti-arrows-exchange\"></i>
                <span>Alterar status</span>
              </button>
              <button id=\"omega-new-ticket\" class=\"omega-btn omega-btn--primary\" type=\"button\">
                <i class=\"ti ti-plus\"></i>
                <span>Registrar chamado</span>
              </button>
            </div>
          </div>

          <div id=\"omega-bulk-panel\" class=\"omega-bulk-panel\" role=\"dialog\" aria-modal=\"false\" hidden>
            <form id=\"omega-bulk-form\" class=\"omega-bulk-form\">
              <header class=\"omega-bulk-form__header\">
                <strong>Alterar status</strong>
                <button type=\"button\" class=\"omega-icon-btn\" id=\"omega-bulk-close\" aria-label=\"Fechar\">
                  <i class=\"ti ti-x\"></i>
                </button>
              </header>
              <p id=\"omega-bulk-hint\">Selecione os chamados desejados para aplicar o novo status.</p>
              <label class=\"omega-field\" for=\"omega-bulk-status-select\">
                <span class=\"omega-field__label\">Novo status</span>
                <select id=\"omega-bulk-status-select\" class=\"omega-select\" required></select>
              </label>
              <footer class=\"omega-bulk-form__actions\">
                <button type=\"button\" class=\"omega-btn omega-btn--ghost\" id=\"omega-bulk-cancel\">Cancelar</button>
                <button type=\"submit\" class=\"omega-btn omega-btn--primary\">
                  <i class=\"ti ti-check\"></i>
                  <span>Aplicar</span>
                </button>
              </footer>
            </form>
          </div>

          <div id=\"omega-summary\" class=\"omega-summary\" aria-live=\"polite\"></div>

          <div class=\"omega-main__content\">
            <div id=\"omega-dashboard\" class=\"omega-dashboard\" hidden aria-live=\"polite\"></div>
            <div id=\"omega-table-wrapper\" class=\"omega-table-wrapper\" role=\"region\" aria-labelledby=\"omega-table-caption\">
              <table class=\"omega-table\" id=\"omega-ticket-table\">
                <caption id=\"omega-table-caption\" class=\"sr-only\">Chamados filtrados pela visão atual</caption>
                <thead>
                  <tr>
                    <th scope=\"col\" class=\"col-select\" aria-label=\"Selecionar\">
                      <input id=\"omega-select-all\" type=\"checkbox\" aria-label=\"Selecionar todos\"/>
                    </th>
                    <th scope=\"col\">ID</th>
                    <th scope=\"col\">Prévia</th>
                    <th scope=\"col\">Departamento</th>
                    <th scope=\"col\">Tipo</th>
                    <th scope=\"col\">Usuário</th>
                    <th scope=\"col\" data-priority-column>Prioridade</th>
                    <th scope=\"col\">Produto</th>
                    <th scope=\"col\">Fila</th>
                    <th scope=\"col\">Abertura</th>
                    <th scope=\"col\">Atualização</th>
                    <th scope=\"col\" class=\"col-status\">Status</th>
                  </tr>
                </thead>
                <tbody id=\"omega-ticket-rows\"></tbody>
              </table>
            </div>
            <footer class=\"omega-table-footer\" aria-live=\"polite\" hidden>
              <span id=\"omega-table-range\" class=\"omega-table-range\">—</span>
              <nav id=\"omega-pagination\" class=\"omega-pagination\" aria-label=\"Paginação de chamados\"></nav>
            </footer>
          </div>
        </section>

      </div>

      <div id=\"omega-drawer\" class=\"omega-drawer\" hidden>
        <div class=\"omega-drawer__overlay\" data-omega-drawer-close></div>
        <section class=\"omega-drawer__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-drawer-title\">
          <header class=\"omega-drawer__header\">
            <div>
              <h3 id=\"omega-drawer-title\">Novo chamado</h3>
              <p id=\"omega-drawer-desc\">Preencha os campos abaixo para registrar o chamado com agilidade.</p>
            </div>
            <button class=\"omega-icon-btn\" type=\"button\" data-omega-drawer-close aria-label=\"Fechar formulário\">
              <i class=\"ti ti-x\"></i>
            </button>
          </header>
          <div id=\"omega-form-feedback\" class=\"omega-feedback\" role=\"alert\" hidden></div>
          <form id=\"omega-form\" class=\"omega-form\">
            <div class=\"omega-field omega-field--static\" aria-live=\"polite\">
              <span class=\"omega-field__label\">Solicitante</span>
              <div id=\"omega-form-requester\" class=\"omega-field__static\">—</div>
            </div>

            <div class=\"omega-form__grid\">
              <label class=\"omega-field\" for=\"omega-form-department\">
                <span class=\"omega-field__label\">Departamento</span>
                <select id=\"omega-form-department\" class=\"omega-select\" required></select>
              </label>
              <label class=\"omega-field\" for=\"omega-form-type\">
                <span class=\"omega-field__label\">Tipo de chamado</span>
                <select id=\"omega-form-type\" class=\"omega-select\" required></select>
              </label>
            </div>

            <label class=\"omega-field\" for=\"omega-form-observation\">
              <span class=\"omega-field__label\">Observação</span>
              <textarea id=\"omega-form-observation\" class=\"omega-textarea\" rows=\"6\" placeholder=\"Descreva a demanda\" required></textarea>
            </label>

            <section id=\"omega-form-flow\" class=\"omega-form-flow\" hidden aria-hidden=\"true\" data-omega-flow>
              <header class=\"omega-form-flow__header\">
                <h4>Fluxo de aprovações</h4>
                <p>Esta transferência exige os de acordo dos gerentes listados abaixo.</p>
              </header>
              <div class=\"omega-form-flow__approvals\">
                <article class=\"omega-flow-approval\">
                  <div class=\"omega-flow-approval__icon\" aria-hidden=\"true\"><i class=\"ti ti-user-check\"></i></div>
                  <div class=\"omega-flow-approval__body\">
                    <span class=\"omega-flow-approval__label\">Gerente da agência solicitante</span>
                    <label class=\"omega-field\" for=\"omega-flow-requester-name\">
                      <span class=\"omega-field__label\">Nome completo</span>
                      <input id=\"omega-flow-requester-name\" class=\"omega-input\" type=\"text\" placeholder=\"Informe o gerente responsável\"/>
                    </label>
                    <label class=\"omega-field\" for=\"omega-flow-requester-email\">
                      <span class=\"omega-field__label\">E-mail corporativo</span>
                      <input id=\"omega-flow-requester-email\" class=\"omega-input\" type=\"email\" placeholder=\"nome.sobrenome@empresa.com\"/>
                    </label>
                  </div>
                </article>
                <article class=\"omega-flow-approval\">
                  <div class=\"omega-flow-approval__icon\" aria-hidden=\"true\"><i class=\"ti ti-building-bank\"></i></div>
                  <div class=\"omega-flow-approval__body\">
                    <span class=\"omega-flow-approval__label\">Gerente da agência cedente</span>
                    <label class=\"omega-field\" for=\"omega-flow-target-name\">
                      <span class=\"omega-field__label\">Nome completo</span>
                      <input id=\"omega-flow-target-name\" class=\"omega-input\" type=\"text\" placeholder=\"Informe o gerente responsável\"/>
                    </label>
                    <label class=\"omega-field\" for=\"omega-flow-target-email\">
                      <span class=\"omega-field__label\">E-mail corporativo</span>
                      <input id=\"omega-flow-target-email\" class=\"omega-input\" type=\"email\" placeholder=\"nome.sobrenome@empresa.com\"/>
                    </label>
                  </div>
                </article>
              </div>
              <p class=\"omega-form-flow__hint\">Após os dois de acordo, o chamado entra automaticamente na fila de Encarteiramento.</p>
            </section>

            <div class=\"omega-field omega-field--attachments\">
              <span class=\"omega-field__label\" id=\"omega-form-file-label\">Arquivos</span>
              <input id=\"omega-form-file\" class=\"sr-only\" type=\"file\" multiple aria-labelledby=\"omega-form-file-label\"/>
              <div class=\"omega-attachments\">
                <div class=\"omega-attachments__actions\">
                  <button class=\"omega-btn\" type=\"button\" data-omega-add-file>
                    <i class=\"ti ti-paperclip\"></i>
                    <span>Adicionar arquivo</span>
                  </button>
                </div>
                <ul id=\"omega-form-attachments\" class=\"omega-attachments__list\" aria-live=\"polite\"></ul>
              </div>
            </div>

            <input id=\"omega-form-product\" type=\"hidden\"/>
            <input id=\"omega-form-subject\" type=\"hidden\"/>

            <footer class=\"omega-form__actions\">
              <button class=\"omega-btn\" type=\"button\" data-omega-drawer-close>Cancelar</button>
              <button class=\"omega-btn omega-btn--primary\" type=\"submit\">
                <i class=\"ti ti-device-floppy\"></i>
                <span>Salvar</span>
              </button>
            </footer>
          </form>
        </section>
      </div>

      <div id=\"omega-ticket-modal\" class=\"omega-ticket-modal\" hidden>
        <div class=\"omega-ticket-modal__overlay\" data-omega-ticket-close></div>
        <section class=\"omega-ticket-modal__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-ticket-modal-title\">
          <header class=\"omega-ticket-modal__header\">
            <div class=\"omega-ticket-modal__titles\">
              <h3 id=\"omega-ticket-modal-title\">Detalhe do chamado</h3>
              <p id=\"omega-ticket-modal-meta\">—</p>
            </div>
            <button class=\"omega-icon-btn\" type=\"button\" data-omega-ticket-close title=\"Fechar detalhamento\">
              <i class=\"ti ti-x\"></i>
            </button>
          </header>
          <div class=\"omega-ticket-modal__body\">
            <section class=\"omega-ticket-progress\" aria-live=\"polite\">
              <ol id=\"omega-ticket-progress\" class=\"omega-progress\"></ol>
            </section>
            <section class=\"omega-ticket-overview\" aria-labelledby=\"omega-ticket-overview-title\">
              <h4 id=\"omega-ticket-overview-title\">Informações do chamado</h4>
              <div class=\"omega-ticket-overview__grid\">
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Solicitante</span>
                  <strong id=\"omega-ticket-requester\">—</strong>
                  <small id=\"omega-ticket-requester-meta\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Responsável</span>
                  <strong id=\"omega-ticket-owner\">—</strong>
                  <small id=\"omega-ticket-owner-meta\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Produto</span>
                  <strong id=\"omega-ticket-product\">—</strong>
                  <small id=\"omega-ticket-queue\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Abertura</span>
                  <strong id=\"omega-ticket-opened\">—</strong>
                  <small id=\"omega-ticket-opened-time\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Status</span>
                  <strong id=\"omega-ticket-status\">—</strong>
                  <small id=\"omega-ticket-updated\">—</small>
                </article>
                <article class=\"omega-ticket-card\">
                  <span class=\"omega-ticket-card__label\">Prioridade</span>
                  <strong id=\"omega-ticket-priority\">—</strong>
                  <small id=\"omega-ticket-due\">—</small>
                </article>
              </div>
            </section>
            <section class=\"omega-ticket-description\" aria-labelledby=\"omega-ticket-description-title\">
              <div class=\"omega-ticket-description__header\">
                <h4 id=\"omega-ticket-description-title\">Descrição</h4>
                <span id=\"omega-ticket-id\">—</span>
              </div>
              <div id=\"omega-ticket-description\" class=\"omega-ticket-description__content\">—</div>
            </section>
            <section class=\"omega-ticket-timeline\" aria-labelledby=\"omega-ticket-timeline-title\">
              <h4 id=\"omega-ticket-timeline-title\">Linha do tempo</h4>
              <ol id=\"omega-ticket-timeline\" class=\"omega-timeline\"></ol>
            </section>
            <section id=\"omega-ticket-actions\" class=\"omega-ticket-actions\" aria-labelledby=\"omega-ticket-actions-title\" hidden>
              <h4 id=\"omega-ticket-actions-title\">Registrar atualização</h4>
              <form id=\"omega-ticket-update-form\" class=\"omega-ticket-actions__form\">
                <div id=\"omega-ticket-actions-advanced\" class=\"omega-ticket-actions__advanced\" hidden>
                  <label class=\"omega-field\" for=\"omega-ticket-update-status\">
                    <span class=\"omega-field__label\">Status</span>
                    <select id=\"omega-ticket-update-status\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-priority\">
                    <span class=\"omega-field__label\">Prioridade</span>
                    <select id=\"omega-ticket-update-priority\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-queue\">
                    <span class=\"omega-field__label\">Fila</span>
                    <select id=\"omega-ticket-update-queue\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-owner\">
                    <span class=\"omega-field__label\">Analista responsável</span>
                    <select id=\"omega-ticket-update-owner\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-category\">
                    <span class=\"omega-field__label\">Tipo de chamado</span>
                    <select id=\"omega-ticket-update-category\" class=\"omega-select\"></select>
                  </label>
                  <label class=\"omega-field\" for=\"omega-ticket-update-due\">
                    <span class=\"omega-field__label\">Prazo</span>
                    <input id=\"omega-ticket-update-due\" class=\"omega-input\" type=\"date\"/>
                  </label>
                </div>
                <label class=\"omega-field\" for=\"omega-ticket-update-comment\">
                  <span class=\"omega-field__label\">Comentário</span>
                  <textarea id=\"omega-ticket-update-comment\" class=\"omega-textarea\" rows=\"4\" placeholder=\"Descreva o andamento\" required></textarea>
                </label>
                <div class=\"omega-field omega-field--attachments\">
                  <span class=\"omega-field__label\" id=\"omega-ticket-update-file-label\">Anexos</span>
                  <input id=\"omega-ticket-update-file\" class=\"sr-only\" type=\"file\" multiple aria-labelledby=\"omega-ticket-update-file-label\"/>
                  <div class=\"omega-attachments\">
                    <div class=\"omega-attachments__actions\">
                      <button class=\"omega-btn\" type=\"button\" data-omega-ticket-add-file>
                        <i class=\"ti ti-paperclip\"></i>
                        <span>Adicionar arquivo</span>
                      </button>
                    </div>
                    <ul id=\"omega-ticket-update-attachments\" class=\"omega-attachments__list\" aria-live=\"polite\"></ul>
                  </div>
                </div>
                <footer class=\"omega-ticket-actions__footer\">
                  <button id=\"omega-ticket-cancel\" class=\"omega-btn omega-btn--danger\" type=\"button\" hidden>
                    <i class=\"ti ti-circle-x\"></i>
                    <span>Cancelar chamado</span>
                  </button>
                  <div class=\"omega-ticket-actions__controls\">
                    <button id=\"omega-ticket-update-reset\" class=\"omega-btn omega-btn--ghost\" type=\"button\">Limpar</button>
                    <button class=\"omega-btn omega-btn--primary\" type=\"submit\">
                      <i class=\"ti ti-message-plus\"></i>
                      <span>Registrar atualização</span>
                    </button>
                  </div>
                </footer>
              </form>
            </section>
          </div>
        </section>
      </div>

      <div id=\"omega-cancel-dialog\" class=\"omega-confirm\" hidden>
        <div class=\"omega-confirm__overlay\" data-omega-cancel-close></div>
        <section class=\"omega-confirm__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-cancel-title\">
          <header class=\"omega-confirm__header\">
            <i class=\"ti ti-circle-x\" aria-hidden=\"true\"></i>
            <div>
              <h3 id=\"omega-cancel-title\">Cancelar chamado</h3>
              <p>Revise as informações antes de confirmar o cancelamento.</p>
            </div>
          </header>
          <div class=\"omega-confirm__body\">
            <div class=\"omega-confirm__ticket\">
              <span>Chamado</span>
              <strong id=\"omega-cancel-ticket-id\">—</strong>
              <small id=\"omega-cancel-ticket-subject\">—</small>
            </div>
            <dl class=\"omega-confirm__meta\">
              <div>
                <dt>Status atual</dt>
                <dd id=\"omega-cancel-ticket-status\">—</dd>
              </div>
              <div>
                <dt>Solicitante</dt>
                <dd id=\"omega-cancel-ticket-requester\">—</dd>
              </div>
            </dl>
            <p id=\"omega-cancel-message\" class=\"omega-confirm__message\">Tem certeza de que deseja cancelar este chamado?</p>
          </div>
          <footer class=\"omega-confirm__actions\">
            <button type=\"button\" class=\"omega-btn omega-btn--ghost\" data-omega-cancel-dismiss>Manter chamado</button>
            <button type=\"button\" class=\"omega-btn omega-btn--danger\" data-omega-cancel-confirm>
              <i class=\"ti ti-circle-x\"></i>
              <span>Cancelar chamado</span>
            </button>
          </footer>
        </section>
      </div>

      <div id=\"omega-manage-analyst\" class=\"omega-manage-modal\" hidden>
        <div class=\"omega-manage-modal__overlay\" data-omega-manage-analyst-close></div>
        <section class=\"omega-manage-modal__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-manage-analyst-title\">
          <header class=\"omega-manage-modal__header\">
            <div>
              <h3 id=\"omega-manage-analyst-title\">Editar analistas</h3>
              <p>Atualize as filas atendidas pelos analistas da sua equipe.</p>
            </div>
            <button type=\"button\" class=\"omega-icon-btn\" data-omega-manage-analyst-close aria-label=\"Fechar edição de analistas\">
              <i class=\"ti ti-x\"></i>
            </button>
          </header>
          <form id=\"omega-manage-analyst-form\" class=\"omega-manage-modal__form\">
            <label class=\"omega-field\" for=\"omega-manage-analyst-select\">
              <span class=\"omega-field__label\">Analista</span>
              <select id=\"omega-manage-analyst-select\" class=\"omega-select\"></select>
            </label>
            <fieldset class=\"omega-field\" aria-describedby=\"omega-manage-analyst-hint\">
              <legend class=\"omega-field__label\">Filas atendidas</legend>
              <div id=\"omega-manage-analyst-queues\" class=\"omega-manage-list\"></div>
              <small id=\"omega-manage-analyst-hint\" class=\"omega-hint\">Marque as filas que o analista deverá acompanhar.</small>
            </fieldset>
            <footer class=\"omega-manage-modal__actions\">
              <button type=\"button\" class=\"omega-btn\" data-omega-manage-analyst-close>Cancelar</button>
              <button type=\"submit\" class=\"omega-btn omega-btn--primary\">
                <i class=\"ti ti-device-floppy\"></i>
                <span>Salvar alterações</span>
              </button>
            </footer>
          </form>
          <div id=\"omega-manage-analyst-empty\" class=\"omega-manage-modal__empty\" hidden></div>
        </section>
      </div>

      <div id=\"omega-manage-status\" class=\"omega-manage-modal\" hidden>
        <div class=\"omega-manage-modal__overlay\" data-omega-manage-status-close></div>
        <section class=\"omega-manage-modal__panel\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"omega-manage-status-title\">
          <header class=\"omega-manage-modal__header\">
            <div>
              <h3 id=\"omega-manage-status-title\">Editar status</h3>
              <p>Personalize os status disponíveis para as filas selecionadas.</p>
            </div>
            <button type=\"button\" class=\"omega-icon-btn\" data-omega-manage-status-close aria-label=\"Fechar edição de status\">
              <i class=\"ti ti-x\"></i>
            </button>
          </header>
          <form id=\"omega-manage-status-form\" class=\"omega-manage-modal__form\">
            <label class=\"omega-field\" for=\"omega-manage-status-department\">
              <span class=\"omega-field__label\">Fila</span>
              <select id=\"omega-manage-status-department\" class=\"omega-select\"></select>
            </label>
            <label class=\"omega-field\" for=\"omega-manage-status-select\">
              <span class=\"omega-field__label\">Status</span>
              <select id=\"omega-manage-status-select\" class=\"omega-select\"></select>
            </label>
            <label class=\"omega-field\" for=\"omega-manage-status-label\">
              <span class=\"omega-field__label\">Título</span>
              <input id=\"omega-manage-status-label\" class=\"omega-input\" type=\"text\" placeholder=\"Nome do status\"/>
            </label>
            <label class=\"omega-field\" for=\"omega-manage-status-tone\">
              <span class=\"omega-field__label\">Tom</span>
              <select id=\"omega-manage-status-tone\" class=\"omega-select\"></select>
            </label>
            <label class=\"omega-field\" for=\"omega-manage-status-description\">
              <span class=\"omega-field__label\">Descrição</span>
              <textarea id=\"omega-manage-status-description\" class=\"omega-textarea\" rows=\"3\" placeholder=\"Quando esse status deve ser utilizado?\"></textarea>
            </label>
            <footer class=\"omega-manage-modal__actions\">
              <button type=\"button\" class=\"omega-btn\" data-omega-manage-status-close>Cancelar</button>
              <button type=\"submit\" class=\"omega-btn omega-btn--primary\">
                <i class=\"ti ti-device-floppy\"></i>
                <span>Salvar alterações</span>
              </button>
            </footer>
          </form>
          <div id=\"omega-manage-status-empty\" class=\"omega-manage-modal__empty\" hidden></div>
        </section>
      </div>
    </section>
  </div>

", "components/modals/omega-modal.twig", "/home/daniel/Documentos/pobj-slim/src/Presentation/Views/components/modals/omega-modal.twig");
    }
}
