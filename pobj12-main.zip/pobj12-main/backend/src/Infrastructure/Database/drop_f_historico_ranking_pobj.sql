-- Script para deletar a tabela f_historico_ranking_pobj
-- Esta tabela foi substituída por f_pontos para o cálculo de ranking

DROP TABLE IF EXISTS f_historico_ranking_pobj;

