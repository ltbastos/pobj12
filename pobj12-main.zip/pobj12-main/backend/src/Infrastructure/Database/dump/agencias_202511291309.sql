INSERT INTO agencias (regional_id,nome,porte,created_at,updated_at) VALUES
	 (8486,'Campo Limpo 1','Medio','2025-11-25 01:54:25','2025-11-25 01:55:05'),
	 (8486,'Faria Lima 2','Medio','2025-11-25 01:54:25','2025-11-25 01:55:05');
