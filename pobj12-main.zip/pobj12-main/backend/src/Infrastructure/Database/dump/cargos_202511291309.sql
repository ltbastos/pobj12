INSERT INTO cargos (nome,created_at,updated_at) VALUES
	 ('Diretor','2025-11-25 02:02:31','2025-11-25 02:02:36'),
	 ('Regional','2025-11-25 02:02:31',NULL),
	 ('Gerente de Gestao','2025-11-25 02:02:31',NULL),
	 ('Gerente','2025-11-25 02:02:31',NULL);
