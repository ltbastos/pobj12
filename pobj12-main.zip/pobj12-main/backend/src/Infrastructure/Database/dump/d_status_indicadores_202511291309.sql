INSERT INTO d_status_indicadores (id,status) VALUES
	 ('01','Atingido'),
	 ('02','Não Atingido'),
	 ('03','Todos');
