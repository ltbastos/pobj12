INSERT INTO f_historico_ranking_pobj (`data`,funcional,grupo,ranking,realizado) VALUES
	 ('2025-11-22','i010001',2,1,780000.00),
	 ('2025-11-22','i020212',2,2,128000.00),
	 ('2025-11-22','i020213',2,3,126000.00);
