INSERT INTO indicador (nm_indicador,familia_id) VALUES
	 ('Cash - Contas a Pagar e Contas a Receber',3),
	 ('Novas Aquisições Alelo',3),
	 ('Produção de Crédito PJ',2),
	 ('Captação Bruta',1);
