INSERT INTO f_detalhes (contrato_id,registro_id,funcional,id_produto,dt_cadastro,competencia,valor_meta,valor_realizado,quantidade,peso,pontos,dt_vencimento,dt_cancelamento,motivo_cancelamento,canal_venda,tipo_venda,condicao_pagamento,status_id) VALUES
	 ('CONT1697CAP001','REAL_1697_CAP001_202501','i010001',1,'2025-01-15','2025-01-01',60000.00,64500.00,6.0000,40.0000,38.0000,NULL,NULL,NULL,'Presencial','Venda ativa','Parcelado','01'),
	 ('CONT3336CRE001','REAL_3336_CRE001_202506','i010001',1,'2025-06-18','2025-06-01',82000.00,83500.00,4.0000,35.0000,34.5000,NULL,NULL,NULL,'Digital','Renovação','À vista','01'),
	 ('CONT7378LIG001','REAL_7378_LIG001_202510','i020212',1,'2025-10-09','2025-10-01',95000.00,98250.00,5.0000,42.0000,41.0000,NULL,NULL,NULL,'Híbrido','Campanha','Parcelado','01'),
	 ('CT-2025-000101','REAL_1697_CAP001_202501','i020212',1,'2025-01-15','2025-01-01',60000.00,64500.00,6.0000,40.0000,38.0000,'2025-02-10',NULL,NULL,'Presencial','Venda ativa','Parcelado','01'),
	 ('CT-2025-000305','REAL_3336_CRE001_202506','i020213',1,'2025-06-18','2025-06-01',82000.00,83500.00,4.0000,35.0000,34.5000,'2025-07-20',NULL,NULL,'Digital','Renovação','À vista','01'),
	 ('CT-2025-000512','REAL_7378_LIG001_202510','i020213',1,'2025-10-09','2025-10-01',95000.00,98250.00,5.0000,42.0000,41.0000,'2025-10-11',NULL,NULL,'Híbrido','Campanha','Parcelado','01');
