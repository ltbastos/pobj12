INSERT INTO omega_departamentos (departamento,departamento_id,ordem_departamento,tipo,ordem_tipo) VALUES
	 ('Visão Global','0',0,'Visão geral',0),
	 ('Encarteiramento','encarteiramento',1,'Fila',1),
	 ('Matriz','matriz',5,'Fila',5),
	 ('Metas','metas',2,'Fila',2),
	 ('Orçamento','orcamento',3,'Fila',3),
	 ('Outros','outros',6,'Fila',6),
	 ('POBJ','pobj',4,'Fila',4);
