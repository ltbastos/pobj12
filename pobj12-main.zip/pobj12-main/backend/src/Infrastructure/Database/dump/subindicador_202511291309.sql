INSERT INTO subindicador (indicador_id,nm_subindicador) VALUES
	 (1,'Contas a Pagar'),
	 (1,'Contas a Receber'),
	 (3,'Linha PJ'),
	 (4,'CDB e Isentos');
