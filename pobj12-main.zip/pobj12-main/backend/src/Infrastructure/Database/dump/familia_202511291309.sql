INSERT INTO familia (nm_familia) VALUES
	 ('Captação'),
	 ('Crédito'),
	 ('Relacionamento');
