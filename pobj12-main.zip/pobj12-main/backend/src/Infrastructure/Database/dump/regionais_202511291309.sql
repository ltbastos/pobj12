INSERT INTO regionais (diretoria_id,nome,created_at,updated_at) VALUES
	 (8607,'SP Sul e Oeste','2025-11-25 01:53:23',NULL);
