INSERT INTO omega_usuarios (id,nome,funcional,cargo,usuario,analista,supervisor,admin,encarteiramento,meta,orcamento,pobj,matriz,outros) VALUES
	 ('usr-01','João Falavinha','012345','Gerente de Relacionamento',1,0,0,0,0,1,0,1,0,0),
	 ('usr-02','Ana Souza','045678','Gerente Regional',1,1,0,0,1,1,0,0,0,0),
	 ('usr-03','Bruno Pereira','078912','Gerente de Gestão',1,0,1,0,0,0,0,1,0,0),
	 ('usr-04','Juliana Costa','078913','Gerente Corporate',1,1,0,0,0,0,0,1,0,0),
	 ('usr-05','Maria Oliveira','012346','Gestora de Carteira',1,0,1,0,1,1,0,1,0,0),
	 ('usr-06','Equipe Matriz','000001','Analista Matriz',1,1,0,0,0,0,1,0,1,1),
	 ('usr-07','Carla Supervisor','045679','Supervisora POBJ',1,0,1,0,0,0,0,1,0,0),
	 ('usr-xburguer','X-Burguer','0897654','Gerente de Relacionamento',1,0,0,0,0,0,0,1,0,0);
