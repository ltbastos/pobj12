INSERT INTO d_produtos (familia_id,indicador_id,subindicador_id,peso,metrica) VALUES
	 (1,1,2,0.15,'valor'),
	 (1,1,3,0.15,'valor'),
	 (1,2,NULL,0.00,'valor'),
	 (2,3,5,0.25,'valor'),
	 (3,4,1,0.25,'Percentual');
