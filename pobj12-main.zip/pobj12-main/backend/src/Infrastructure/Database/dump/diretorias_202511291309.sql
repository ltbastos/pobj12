INSERT INTO diretorias (segmento_id,nome,created_at,updated_at) VALUES
	 (1,'Empresas','2025-11-25 01:52:39',NULL);
