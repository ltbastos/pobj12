INSERT INTO segmentos (nome,created_at,updated_at) VALUES
	 ('Empresas','2025-11-25 01:49:34','2025-11-25 01:52:08');
