<?php

namespace App\Application\UseCase\Omega;

use App\Domain\DTO\FilterDTO;


class OmegaMesuUseCase
{
    public function __construct()
    {
    }

    
    public function handle(?FilterDTO $filters = null): array
    {
                                return [];
    }
}



