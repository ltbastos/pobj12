<?php

namespace App\Application\UseCase\Omega;

use App\Entity\Omega\OmegaChamado;
use App\Repository\Omega\OmegaChamadoRepository;
use App\Repository\Omega\OmegaStatusRepository;
use App\Repository\Omega\OmegaDepartamentoRepository;
use App\Repository\Omega\OmegaUsuarioRepository;


class OmegaTicketsUseCase
{
    private $repository;
    private $statusRepository;
    private $departamentoRepository;
    private $usuarioRepository;

    public function __construct(
        OmegaChamadoRepository $repository,
        OmegaStatusRepository $statusRepository,
        OmegaDepartamentoRepository $departamentoRepository,
        OmegaUsuarioRepository $usuarioRepository
    ) {
        $this->repository = $repository;
        $this->statusRepository = $statusRepository;
        $this->departamentoRepository = $departamentoRepository;
        $this->usuarioRepository = $usuarioRepository;
    }

    
    public function getAllTickets(): array
    {
        return $this->repository->findAllOrderedByUpdated();
    }

    public function handle($filters = null): array
    {
        return $this->getAllTickets();
    }

    
    public function createTicket(array $data): OmegaChamado
    {
        $ticket = new OmegaChamado();
        
                $ticket->setId($this->repository->generateNextTicketId());
        
                $this->mapBasicData($ticket, $data);
        
                $this->mapRelationships($ticket, $data);
        
                $this->mapContextAndHistory($ticket, $data);
        
                $this->repository->save($ticket);
        
        return $ticket;
    }

    
    private function mapBasicData(OmegaChamado $ticket, array $data): void
    {
        $ticket->setSubject($data['subject'] ?? 'Chamado Omega');
        $ticket->setCompany($data['company'] ?? null);
        $ticket->setProductId($data['productId'] ?? null);
        $ticket->setProductLabel($data['product'] ?? null);
        $ticket->setFamily($data['family'] ?? null);
        $ticket->setSection($data['section'] ?? null);
        $ticket->setQueue($data['queue'] ?? null);
        $ticket->setCategory($data['category'] ?? null);
        $ticket->setPriority($data['priority'] ?? 'media');
        
        $now = new \DateTime();
        $ticket->setOpened($now);
        $ticket->setUpdated($now);
        
        if (isset($data['dueDate']) && $data['dueDate']) {
            $ticket->setDueDate(new \DateTime($data['dueDate']));
        }
    }

    
    private function mapRelationships(OmegaChamado $ticket, array $data): void
    {
                $statusLabel = $data['status'] ?? 'aberto';
        $status = $this->statusRepository->findByLabel($statusLabel) 
            ?? $this->statusRepository->findByLabel('aberto');
        $ticket->setStatus($status);
        
                if (isset($data['requesterId'])) {
            $requester = $this->usuarioRepository->find($data['requesterId']);
            $ticket->setRequester($requester);
        }
        
                if (isset($data['ownerId']) && $data['ownerId']) {
            $owner = $this->usuarioRepository->find($data['ownerId']);
            $ticket->setOwner($owner);
        }
        
                if (isset($data['teamId']) && $data['teamId']) {
                        if (is_numeric($data['teamId'])) {
                $team = $this->departamentoRepository->find($data['teamId']);
            } else {
                $team = $this->departamentoRepository->findByNomeId($data['teamId']);
            }
            $ticket->setTeam($team);
        } elseif (isset($data['queue']) && $data['queue']) {
            $team = $this->departamentoRepository->findByNome($data['queue']);
            $ticket->setTeam($team);
        }
    }

    
    private function mapContextAndHistory(OmegaChamado $ticket, array $data): void
    {
                if (isset($data['context'])) {
            $context = $data['context'];
            $ticket->setDiretoria($context['diretoria'] ?? null);
            $ticket->setGerencia($context['gerencia'] ?? null);
            $ticket->setAgencia($context['agencia'] ?? null);
            $ticket->setGerenteGestao($context['ggestao'] ?? null);
            $ticket->setGerente($context['gerente'] ?? null);
        }
        
                if (isset($data['history']) && is_array($data['history'])) {
            $historyData = $this->formatHistory($data['history']);
            $ticket->setHistory(json_encode($historyData, JSON_UNESCAPED_UNICODE));
        } elseif (isset($data['observation'])) {
            $historyData = [[
                'date' => (new \DateTime())->format('Y-m-d\TH:i:s\Z'),
                'action' => 'Abertura do chamado',
                'comment' => $data['observation']
            ]];
            $ticket->setHistory(json_encode($historyData, JSON_UNESCAPED_UNICODE));
        }
    }

    
    public function updateTicket(string $id, array $data): ?OmegaChamado
    {
        $ticket = $this->repository->find($id);
        
        if (!$ticket) {
            return null;
        }
        
                if (isset($data['subject'])) {
            $ticket->setSubject($data['subject']);
        }
        
        if (isset($data['priority'])) {
            $ticket->setPriority($data['priority']);
        }
        
        if (isset($data['queue'])) {
            $ticket->setQueue($data['queue']);
        }
        
        if (isset($data['category'])) {
            $ticket->setCategory($data['category']);
        }
        
        if (isset($data['dueDate'])) {
            $ticket->setDueDate($data['dueDate'] ? new \DateTime($data['dueDate']) : null);
        }
        
                if (isset($data['updated'])) {
            try {
                $ticket->setUpdated(new \DateTime($data['updated']));
            } catch (\Exception $e) {
                $ticket->setUpdated(new \DateTime());
            }
        } else {
            $ticket->setUpdated(new \DateTime());
        }
        
                if (isset($data['status'])) {
                        $status = $this->statusRepository->find($data['status']);
            if (!$status) {
                                $status = $this->statusRepository->findByLabel($data['status']);
            }
            if ($status) {
                $ticket->setStatus($status);
            }
        }
        
                if (isset($data['requesterId'])) {
            $requester = $this->usuarioRepository->find($data['requesterId']);
            if ($requester) {
                $ticket->setRequester($requester);
            }
        }
        
        if (isset($data['ownerId'])) {
            $owner = $data['ownerId'] ? $this->usuarioRepository->find($data['ownerId']) : null;
            $ticket->setOwner($owner);
        }
        
        if (isset($data['teamId'])) {
            if ($data['teamId']) {
                                if (is_numeric($data['teamId'])) {
                    $team = $this->departamentoRepository->find($data['teamId']);
                } else {
                    $team = $this->departamentoRepository->findByNomeId($data['teamId']);
                }
            } else {
                $team = null;
            }
            $ticket->setTeam($team);
        }
        
                if (isset($data['history']) && is_array($data['history'])) {
            $historyData = $this->formatHistory($data['history']);
            $ticket->setHistory(json_encode($historyData, JSON_UNESCAPED_UNICODE));
        }
        
                if (isset($data['context']) && is_array($data['context'])) {
            $context = $data['context'];
            if (isset($context['diretoria'])) {
                $ticket->setDiretoria($context['diretoria']);
            }
            if (isset($context['gerencia'])) {
                $ticket->setGerencia($context['gerencia']);
            }
            if (isset($context['agencia'])) {
                $ticket->setAgencia($context['agencia']);
            }
            if (isset($context['ggestao'])) {
                $ticket->setGerenteGestao($context['ggestao']);
            }
            if (isset($context['gerente'])) {
                $ticket->setGerente($context['gerente']);
            }
        }
        
                $this->repository->save($ticket);
        
        return $ticket;
    }

    
    private function formatHistory(array $history): array
    {
        $formatted = [];
        foreach ($history as $entry) {
            $formatted[] = [
                'date' => $entry['date'] ?? null,
                'actorId' => $entry['actorId'] ?? null,
                'action' => $entry['action'] ?? 'Abertura do chamado',
                'comment' => $entry['comment'] ?? '',
                'status' => $entry['status'] ?? 'aberto'
            ];
        }
        return $formatted;
    }
    
    
    public function ticketToArray(OmegaChamado $ticket): array
    {
        $status = $ticket->getStatus();
        $requester = $ticket->getRequester();
        $owner = $ticket->getOwner();
        $team = $ticket->getTeam();
        
        return [
            'id' => $ticket->getId(),
            'subject' => $ticket->getSubject(),
            'company' => $ticket->getCompany(),
            'product_id' => $ticket->getProductId(),
            'product_label' => $ticket->getProductLabel(),
            'family' => $ticket->getFamily(),
            'section' => $ticket->getSection(),
            'queue' => $ticket->getQueue(),
            'category' => $ticket->getCategory(),
            'status' => $status ? $status->getId() : null,
            'priority' => $ticket->getPriority(),
            'opened' => $ticket->getOpened() ? $ticket->getOpened()->format('Y-m-d\TH:i:s\Z') : null,
            'updated' => $ticket->getUpdated() ? $ticket->getUpdated()->format('Y-m-d\TH:i:s\Z') : null,
            'due_date' => $ticket->getDueDate() ? $ticket->getDueDate()->format('Y-m-d\TH:i:s\Z') : null,
            'requester_id' => $requester ? $requester->getId() : null,
            'owner_id' => $owner ? $owner->getId() : null,
            'team_id' => $team ? $team->getNomeId() : null,
            'history' => $ticket->getHistory(),
            'diretoria' => $ticket->getDiretoria(),
            'gerencia' => $ticket->getGerencia(),
            'agencia' => $ticket->getAgencia(),
            'gerente_gestao' => $ticket->getGerenteGestao(),
            'gerente' => $ticket->getGerente(),
            'credit' => $ticket->getCredit(),
            'attachment' => $ticket->getAttachment()
        ];
    }
}

