<?php

namespace App\Application\UseCase\Pobj;

use App\Application\UseCase\AbstractUseCase;

class CampanhasUseCase extends AbstractUseCase
{
    public function __construct()
    {
    }
}

