<?php

namespace App\Application\UseCase\Pobj;

use App\Application\UseCase\AbstractUseCase;


class MesuUseCase extends AbstractUseCase
{
    public function __construct()
    {
    }
}

