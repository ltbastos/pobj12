<script setup lang="ts">
import OmegaModal from './OmegaModal.vue'
</script>

<template>
  <OmegaModal />
</template>
